<?php

use Illuminate\Database\Seeder;

class PagesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $titles_slugs = [
            'home' => 'Welcome on the homepage',
            'about' => 'Everything you need to know about us!',
            'services' => 'Learn everything about our services',
            'privacy policy' => 'Our privacy policy'
        ];

        foreach ($titles_slugs as $title => $slug) {
            factory(App\Models\Page::class)->create([
                'title' => $title,
                'slug' => $slug,
            ]);
        }
            
        
        
    }
}
