<?php

use Illuminate\Database\Seeder;

class CategoriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $data = [
            [
                'name' => 'Arts',
                'description' => 'Discover artists who use Fundrain to realize their projects in visual art and performance.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Comics & Illustrations',
                'description' => 'Explore fantastical worlds and original characters form our community of comics creators and illustrators',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Digital Arts',
                'description' => 'Discover the greatest artists who use Fundrain to realize their projects and dreams in digital arts.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Design & Tech',
                'description' => 'from the finest designs to the most innovative tech, discover the projects from creators working to build a more beautiful future',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Food & Craft',
                'description' => 'See how artisans and entrepreneurs are using Fundrain to break new ground in food, fashion, and crafts.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Games',
                'description' => 'From tabletop adventures to beloved revivals, discover the projects forging the future of gameplay.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Music',
                'description' => 'Discover new albums, performances, and independent venues from creators using Fundrain to shape the future of sound.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Publishing',
                'description' => 'Explore how writers and publishers are using Fundrain to bring new literature, periodicals, podcasts, and more to life.',
                'parent_category' => NULL,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Dance',
                'description' => 'Find all projects, events and groups related to dance here',
                'parent_category' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Theater',
                'description' => 'Find all projects, events and groups related to theather here',
                'parent_category' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Painting and drawing',
                'description' => 'Find all projects, events and products related to painting or drawing here',
                'parent_category' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name'=> 'Photography',
                'description' => 'Discover the most beautiful photographs, best workshops and great projects here',
                'parent_catogory'=> 2,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Film & Video',
                'description' => 'Join forces with the intrepid filmmakers and festival creators changing the way stories get told on screen.',
                'parent_category' => 2,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Design',
                'description' => 'Dive into the world of the most beautiful designed products',
                'parent_category' => 4,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Technology',
                'description' => 'Improve the future, innovating tech of today that will change tomorrow.',
                'parent_category' => 4,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Crafts',
                'description' => 'Discover the most beautiful craft',
                'parent_category' => 5,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Fashion',
                'description' => 'Take part in the newest upcoming fashion',
                'parent_category' => 5,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Food',
                'description' => 'Take a leap foward to a healthier life with the newest food trends',
                'parent_category' => 5,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Journalism',
                'description' => 'Discover the newest things in journalism',
                'parent_category' => 8,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'name' => 'Publishing',
                'description' => 'Discover the newest books, podcasts, stories and so much more.',
                'parent_category' => 8,
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
        ];

        App\Models\Categorie::insert($data);
    }
}
